(function initializeOFBUnifiedExporter() {
  "use strict";

  const SOURCE = "ofb-order-csv-exporter";
  const GRID_ID = "grdOrderIndex";
  const PANEL_ID = "ofb-batch-export-panel";
  const NETWORK_TIMEOUT_MS = 120000;

  let activeBatchId = null;
  let cancelRequested = false;
  let reconciliation = [];
  let runSummary = null;

  function exportCore() {
    if (!globalThis.OFBExportCore) throw new Error("The order export helper did not load. Reload the extension and Order History.");
    return globalThis.OFBExportCore;
  }

  function freshCore() {
    if (!globalThis.OFBFreshAllianceCore) throw new Error("The Fresh Alliance export helper did not load. Reload the extension and Order History.");
    return globalThis.OFBFreshAllianceCore;
  }

  function unifiedCore() {
    if (!globalThis.OFBUnifiedExportCore) throw new Error("The unified export helper did not load. Reload the extension and Order History.");
    return globalThis.OFBUnifiedExportCore;
  }

  function element(id) {
    return document.getElementById(id);
  }

  function makeBatchId() {
    return `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  }

  function bridgeRequest(type, responseType, payload, batchId) {
    return new Promise((resolve, reject) => {
      const requestId = makeBatchId();
      const timeout = window.setTimeout(() => {
        window.removeEventListener("message", receive);
        reject(Object.assign(new Error("Primarius did not respond before the request timed out."), { code: "TIMEOUT" }));
      }, NETWORK_TIMEOUT_MS);

      function receive(event) {
        const message = event.data;
        if (
          event.source !== window ||
          message?.source !== SOURCE ||
          message?.type !== responseType ||
          message?.requestId !== requestId
        ) return;
        window.clearTimeout(timeout);
        window.removeEventListener("message", receive);
        if (message.ok) resolve(message);
        else {
          const error = new Error(message.error || "The Primarius request failed.");
          error.code = message.code || "REQUEST_FAILED";
          error.expectedRows = message.expectedRows;
          error.extractedRows = message.extractedRows;
          reject(error);
        }
      }

      window.addEventListener("message", receive);
      window.postMessage({ source: SOURCE, type, requestId, batchId, ...payload }, "*");
    });
  }

  function setStatus(message, type = "") {
    const status = element("ofb-batch-status");
    if (!status) return;
    status.textContent = message;
    status.dataset.type = type;
  }

  function setBusy(busy) {
    element("ofb-batch-export").disabled = busy;
    element("ofb-batch-start").disabled = busy;
    element("ofb-batch-end").disabled = busy;
    element("ofb-batch-cancel").hidden = !busy;
    element("ofb-batch-cancel").disabled = false;
  }

  function resetResults() {
    if (activeBatchId) return;
    reconciliation = [];
    runSummary = null;
    element("ofb-batch-reconciliation").hidden = true;
    setStatus("Choose one date range, then export all Warehouse and Fresh Alliance records.");
  }

  function selectedDates() {
    const startDate = element("ofb-batch-start").value;
    const endDate = element("ofb-batch-end").value;
    return {
      startDate,
      endDate,
      orderHistoryRequest: exportCore().buildHistoryRequest(startDate, endDate).data,
      pickupHistoryRequest: freshCore().buildPickupHistoryRequest(startDate, endDate).data,
    };
  }

  function downloadCsv(filename, rows) {
    const csv = unifiedCore().toCsv(rows);
    const blob = new Blob(["\uFEFF", csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    link.hidden = true;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function renderReconciliation() {
    const details = element("ofb-batch-reconciliation");
    const summary = details.querySelector("summary");
    const output = element("ofb-batch-reconciliation-output");
    const failures = reconciliation.filter((item) => item.status !== "ok");
    const expected = reconciliation.reduce((sum, item) => sum + (Number(item.expectedRows) || 0), 0);
    const extracted = reconciliation.reduce((sum, item) => sum + (Number(item.extractedRows) || 0), 0);
    const pickupItems = reconciliation.filter((item) => item.kind === "agency_pickup" && item.status === "ok");
    const pendingRequestedWeight = pickupItems
      .filter((item) => !item.confirmed)
      .reduce((sum, item) => sum + Number(item.requestedWeight), 0);
    const pendingReceivedWeight = pickupItems
      .filter((item) => !item.confirmed)
      .reduce((sum, item) => sum + Number(item.receivedWeight), 0);
    const completedRequestedWeight = pickupItems
      .filter((item) => item.confirmed)
      .reduce((sum, item) => sum + Number(item.requestedWeight), 0);
    const completedReceivedWeight = pickupItems
      .filter((item) => item.confirmed)
      .reduce((sum, item) => sum + Number(item.receivedWeight), 0);
    const channelSummary = runSummary
      ? `${runSummary.warehouseOrders} Warehouse orders; ${runSummary.pendingPickups} Pending and ${runSummary.completedPickups} Completed Fresh Alliance pickups; ${runSummary.excludedAgencyPickupOrders} duplicate AGPCKUP warehouse orders excluded`
      : "The three source indexes did not all reconcile";
    const weightSummary = runSummary
      ? `; Pending requested/received lb=${pendingRequestedWeight.toFixed(2)}/${pendingReceivedWeight.toFixed(2)}; Completed requested/received lb=${completedRequestedWeight.toFixed(2)}/${completedReceivedWeight.toFixed(2)}`
      : "";
    summary.textContent = `Reconciliation: ${channelSummary}; ${expected} expected detail rows, ${extracted} extracted${weightSummary}${failures.length ? `; ${failures.length} failed or skipped` : ""}`;
    output.textContent = reconciliation.map((item) => {
      const counts = `expected=${item.expectedRows ?? "unknown"}, extracted=${item.extractedRows ?? "unknown"}`;
      const status = item.confirmed === undefined ? "" : `; Confirmed=${item.confirmed ? "Yes" : "No"}`;
      const weights = item.kind === "agency_pickup" && item.status === "ok"
        ? `; requested lb=${Number(item.requestedWeight).toFixed(2)}, received lb=${Number(item.receivedWeight).toFixed(2)}`
        : "";
      const differences = item.confirmed && item.discrepancyLines
        ? `; ${item.discrepancyLines} requested/received line difference(s)`
        : "";
      return `${item.kind}: ${item.reference} (ID ${item.id}): ${item.status}; ${counts}${status}${weights}${differences}${item.error ? `; ${item.error}` : ""}`;
    }).join("\n");
    details.hidden = false;
    details.open = failures.length > 0;
  }

  function skippedItem(task, reason) {
    return {
      kind: task.kind,
      id: task.record.id,
      reference: task.record.reference,
      confirmed: task.record.confirmed,
      status: "skipped",
      error: reason,
    };
  }

  async function exportUnified() {
    let dates;
    try {
      dates = selectedDates();
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Choose a valid date range.", "error");
      return;
    }

    activeBatchId = makeBatchId();
    cancelRequested = false;
    reconciliation = [];
    runSummary = null;
    setBusy(true);
    element("ofb-batch-reconciliation").hidden = true;

    try {
      setStatus("Reading Warehouse Completed orders…", "working");
      const orderHistory = await bridgeRequest(
        "HISTORY_REQUEST",
        "HISTORY_RESPONSE",
        { historyRequest: dates.orderHistoryRequest },
        activeBatchId,
      );
      if (cancelRequested) throw Object.assign(new Error("Unified export cancelled."), { code: "CANCELLED" });

      // The state transition is one-way: Pending -> Completed. Sampling Pending
      // first turns a mid-export transition into a duplicate that can be safely
      // resolved in favor of Completed instead of an omission.
      setStatus("Reading Fresh Alliance Pending pickups…", "working");
      const pendingHistory = await bridgeRequest(
        "UNIFIED_PICKUP_HISTORY_REQUEST",
        "UNIFIED_PICKUP_HISTORY_RESPONSE",
        { status: "pending", historyRequest: dates.pickupHistoryRequest },
        activeBatchId,
      );
      if (cancelRequested) throw Object.assign(new Error("Unified export cancelled."), { code: "CANCELLED" });

      setStatus("Reading Fresh Alliance Completed pickups…", "working");
      const completedHistory = await bridgeRequest(
        "UNIFIED_PICKUP_HISTORY_REQUEST",
        "UNIFIED_PICKUP_HISTORY_RESPONSE",
        { status: "completed", historyRequest: dates.pickupHistoryRequest },
        activeBatchId,
      );
      if (cancelRequested) throw Object.assign(new Error("Unified export cancelled."), { code: "CANCELLED" });

      const warehouse = unifiedCore().normalizeWarehouseOrders(orderHistory.rawRows, dates.startDate, dates.endDate);
      const pending = freshCore().normalizePendingPickups(pendingHistory.rawRows, dates.startDate, dates.endDate);
      const completed = freshCore().normalizeCompletedPickups(completedHistory.rawRows, dates.startDate, dates.endDate);
      const merged = unifiedCore().mergePickupSnapshots(pending.pickups, completed.pickups);

      runSummary = {
        warehouseOrders: warehouse.orders.length,
        pendingPickups: merged.pickups.filter((pickup) => !pickup.confirmed).length,
        completedPickups: merged.pickups.filter((pickup) => pickup.confirmed).length,
        excludedAgencyPickupOrders: warehouse.excludedAgencyPickupOrders.length,
        transitionDuplicatesRemoved: merged.transitionDuplicatesRemoved,
      };

      const tasks = [
        ...warehouse.orders.map((record) => ({ kind: "warehouse_order", record })),
        ...merged.pickups.map((record) => ({ kind: "agency_pickup", record })),
      ];
      const exports = [];
      let stopForSession = false;

      for (let index = 0; index < tasks.length; index += 1) {
        const task = tasks[index];
        if (cancelRequested || stopForSession) {
          reconciliation.push(skippedItem(
            task,
            cancelRequested ? "Unified export cancelled." : "Skipped after the Primarius session expired.",
          ));
          continue;
        }

        setStatus(`Processing ${index + 1} of ${tasks.length}: ${task.record.reference}…`, "working");
        let expectedRows;
        let extractedRows;
        try {
          if (task.kind === "warehouse_order") {
            const result = await bridgeRequest(
              "ORDER_ROWS_REQUEST",
              "ORDER_ROWS_RESPONSE",
              { orderId: task.record.id },
              activeBatchId,
            );
            expectedRows = result.expectedRows;
            extractedRows = result.extractedRows;
            if (result.expectedRows !== result.extractedRows || result.rows.length !== result.expectedRows) {
              throw Object.assign(new Error(`Order ${task.record.reference} row counts did not match.`), {
                code: "ROW_COUNT_MISMATCH",
                expectedRows: result.expectedRows,
                extractedRows: result.rows.length,
              });
            }
            const exported = unifiedCore().buildWarehouseExport(task.record, result.rows);
            exports.push(exported);
            reconciliation.push({
              kind: task.kind,
              id: task.record.id,
              reference: task.record.reference,
              status: "ok",
              expectedRows: result.expectedRows,
              extractedRows: exported.rows.length,
            });
          } else {
            const result = await bridgeRequest(
              "UNIFIED_PICKUP_ROWS_REQUEST",
              "UNIFIED_PICKUP_ROWS_RESPONSE",
              { pickupId: task.record.id },
              activeBatchId,
            );
            expectedRows = result.reportedRows;
            extractedRows = result.extractedRows;
            if (result.reportedRows !== result.extractedRows || result.rawRows.length !== result.reportedRows) {
              throw Object.assign(new Error(`Pickup ${task.record.reference} row counts did not match.`), {
                code: "ROW_COUNT_MISMATCH",
                expectedRows: result.reportedRows,
                extractedRows: result.rawRows.length,
              });
            }
            const exported = unifiedCore().buildPickupExport(task.record, result.rawRows);
            exports.push(exported);
            reconciliation.push({
              kind: task.kind,
              id: task.record.id,
              reference: task.record.reference,
              confirmed: task.record.confirmed,
              status: "ok",
              expectedRows: result.reportedRows,
              extractedRows: exported.rows.length,
              requestedWeight: exported.requestedWeight,
              receivedWeight: exported.receivedWeight,
              discrepancyLines: exported.discrepancyLines,
            });
          }
        } catch (error) {
          if (error?.code === "CANCELLED") cancelRequested = true;
          if (error?.code === "SESSION_EXPIRED") stopForSession = true;
          reconciliation.push({
            kind: task.kind,
            id: task.record.id,
            reference: task.record.reference,
            confirmed: task.record.confirmed,
            status: "failed",
            expectedRows: error?.expectedRows ?? expectedRows,
            extractedRows: error?.extractedRows ?? extractedRows,
            error: error instanceof Error ? error.message : "Record retrieval failed.",
          });
        }
      }

      const failures = reconciliation.filter((item) => item.status !== "ok");
      renderReconciliation();
      if (cancelRequested) {
        setStatus("Unified export cancelled. No CSV was created.", "error");
      } else if (failures.length) {
        setStatus(`Unified export failed for ${failures.length} records. No partial CSV was created.`, "error");
      } else {
        const rows = unifiedCore().combineRows(exports);
        downloadCsv(unifiedCore().buildFilename(dates.startDate, dates.endDate), rows);
        const transitionNote = runSummary.transitionDuplicatesRemoved
          ? ` ${runSummary.transitionDuplicatesRemoved} Pending-to-Completed transition duplicate was resolved in favor of Completed.`
          : "";
        setStatus(`Exported ${rows.length} rows across both OFB channels.${transitionNote}`, "success");
      }
    } catch (error) {
      if (error?.code === "CANCELLED" || cancelRequested) {
        setStatus("Unified export cancelled. No CSV was created.", "error");
      } else {
        setStatus(`${error instanceof Error ? error.message : "Unified export failed."} No CSV was created.`, "error");
      }
      renderReconciliation();
    } finally {
      activeBatchId = null;
      setBusy(false);
    }
  }

  function cancelExport() {
    if (!activeBatchId) return;
    cancelRequested = true;
    window.postMessage({ source: SOURCE, type: "CANCEL_BATCH", batchId: activeBatchId }, "*");
    setStatus("Cancelling after the current request…", "working");
    element("ofb-batch-cancel").disabled = true;
  }

  function createLabeledDate(id, labelText) {
    const label = document.createElement("label");
    label.setAttribute("for", id);
    label.textContent = labelText;
    const input = document.createElement("input");
    input.id = id;
    input.type = "date";
    input.required = true;
    input.addEventListener("change", resetResults);
    label.append(input);
    return label;
  }

  function addUnifiedExporter() {
    if (element(PANEL_ID)) return true;
    const grid = element(GRID_ID);
    if (!grid) return false;

    const panel = document.createElement("section");
    panel.id = PANEL_ID;
    panel.setAttribute("aria-labelledby", "ofb-batch-title");
    const title = document.createElement("h3");
    title.id = "ofb-batch-title";
    title.textContent = "Export complete OFB data";
    const description = document.createElement("p");
    description.textContent = "One date range exports Warehouse Completed orders plus Fresh Alliance Pending and Completed pickups. No partial file is created.";

    const controls = document.createElement("div");
    controls.id = "ofb-batch-controls";
    const start = createLabeledDate("ofb-batch-start", "Start date");
    const end = createLabeledDate("ofb-batch-end", "End date");
    const exportButton = document.createElement("button");
    exportButton.id = "ofb-batch-export";
    exportButton.type = "button";
    exportButton.textContent = "Export unified CSV";
    exportButton.addEventListener("click", exportUnified);
    const cancel = document.createElement("button");
    cancel.id = "ofb-batch-cancel";
    cancel.type = "button";
    cancel.textContent = "Cancel";
    cancel.hidden = true;
    cancel.addEventListener("click", cancelExport);
    controls.append(start, end, exportButton, cancel);

    const status = document.createElement("p");
    status.id = "ofb-batch-status";
    status.setAttribute("role", "status");
    status.setAttribute("aria-live", "polite");
    status.textContent = "Choose one date range, then export all Warehouse and Fresh Alliance records.";

    const details = document.createElement("details");
    details.id = "ofb-batch-reconciliation";
    details.hidden = true;
    const summary = document.createElement("summary");
    const output = document.createElement("pre");
    output.id = "ofb-batch-reconciliation-output";
    details.append(summary, output);

    panel.append(title, description, controls, status, details);
    grid.parentElement?.insertBefore(panel, grid);
    return true;
  }

  if (!addUnifiedExporter()) {
    const observer = new MutationObserver(() => {
      if (addUnifiedExporter()) observer.disconnect();
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
    window.setTimeout(() => observer.disconnect(), 30000);
  }
})();
