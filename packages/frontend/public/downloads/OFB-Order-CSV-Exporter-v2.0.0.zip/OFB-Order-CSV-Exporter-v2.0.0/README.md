# OFB Order CSV Exporter

OFB Order CSV Exporter is a focused Chrome extension for Oregon Food Bank Primarius. It exports one **View Order** page or creates one comprehensive date-range CSV covering Warehouse Completed orders plus Fresh Alliance Pending and Completed pickups.

## What it exports

The unified CSV contains:

`Schema Version`, `Record Type`, `Confirmed`, `Date`, `Period`, `Source Reference`, `Product #`, `Product Description`, `Category`, `Qty`, `Weight`, `Unit Price`, `Price Total`, `Service Fee`, `Grants Applied`, `Pickup Time`, `Pickup ID`, `Pickup Line ID`, `Donor Code`, `Donor Name`, `Fresh Alliance Category`, `Received Qty`, `Received Weight`, `Temperature`, `Submitted Date/Time`, and `Donor Value Per Pound`.

The exporter:

- uses the displayed pickup/delivery date and order reference;
- reads Warehouse Completed orders and both Fresh Alliance pickup statuses for exactly one inclusive date range;
- excludes warehouse-form order references ending in `AGPCKUP`, because the richer Agency Pickup record represents the same donation event;
- states channel and review status explicitly with `Record Type` and `Confirmed` rather than inferring them from references or blank values;
- reads all server-backed rows regardless of the current 5/10/20/50-row view;
- preserves observed four-, five-, and six-digit product identifiers and normalizes narrowly defined legacy `x`, `z`, `-Z`, `.0`, and `.1` label variants;
- assigns `DONATED`, `PURCH-DON`, `GOVERNMENT`, or `PURCHASED` from the product-number family, including observed `4xxxx` Fresh Alliance products as `DONATED`;
- calculates `Price Total` from quantity and the displayed, cent-rounded unit price;
- sorts an individual order by product number and a unified export deterministically by date, channel, source reference, product, and line ID;
- creates an Excel-friendly UTF-8 CSV; and
- refuses to create a partial file unless Warehouse Completed, Fresh Alliance Pending, Fresh Alliance Completed, and every included detail table all reconcile.

Fresh Alliance rows retain requested `Qty` and `Weight` exactly as Primarius
reports them. `Received Qty` and `Received Weight` are also retained exactly,
including real `0` values on Pending pickups; `Confirmed=No` states what those
zeros mean. Donor contacts, telephone numbers, email addresses, comments, and
street addresses are not exported.

The individual View Order export retains its established twelve-column format.

## Install in Chrome

1. Download and unzip the release archive, or clone this repository.
2. Open `chrome://extensions`.
3. Turn on **Developer mode**.
4. Choose **Load unpacked**.
5. Select the unzipped project folder.
6. Reload an open Primarius **Order History** or **View Order** page.

The extension runs only on the Primarius Order History and matching View Order pages.

## Use

### Export a complete date range

1. Sign in to Primarius normally and open **Order History**.
2. Choose inclusive **Start date** and **End date** values. They apply to Warehouse **Delivery/Pickup** and Fresh Alliance **Pickup Date**.
3. Choose **Export unified CSV**.
4. Keep the page open while the extension reads all three source indexes and processes details sequentially. You can cancel the run.
5. Confirm that the success status and reconciliation counts match expectations.

The file is named `OFB_Export_YYYY-MM-DD_to_YYYY-MM-DD.csv`. Pending pickups are sampled before Completed pickups so a pickup confirmed mid-export can be deduplicated safely in favor of its Completed state. If any source fails, changes during retrieval, contains conflicting identity, or reports a different extracted row count, no partial CSV is downloaded. The on-page reconciliation identifies failures and skipped records. An expired Primarius session stops the run explicitly.

### Export one order

1. From **Order History**, select **View** for an order.
2. Choose **Export as CSV** above the order-detail table.
3. Confirm that the status reports the expected exported row count.

Choose the **Info** icon beside the export button for product details, credits,
version, license, privacy information, and a link to the source code.

The extension does not collect credentials, transmit Primarius data to another
service, or run outside the matching Order History and order-detail pages. See
[PRIVACY.md](PRIVACY.md).

## Fresh Alliance integration verified July 17, 2026

- Agency Pickups grid DOM ID: `GrdPreviousAgencyPickups`.
- Pickup sources: `/PWW/AgencyPickup/GetIndexDataAgencyPickup_Pending` and
  `/PWW/AgencyPickup/GetIndexDataAgencyPickup_Completed`.
- Pending rows carry `SystemReceived: false`, populated requested values, and
  real received `0` values. Completed rows carry `SystemReceived: true`.
- Pickup membership is filtered inclusively on `ExpectedDate`, the displayed
  Pickup Date. `CreatedOn` is the distinct Submitted Date.
- Stable pickup fields include `Id`, `ReferenceCode`, `ContributorId`, donor
  code/name fields, `ExpectedDate`, `CreatedOn`, `ConfirmedDate`,
  `SystemReceivedDate`, and `SystemReceived`.
- Detail grid DOM ID: `grdPrevAgencyPickupDetailsIndex`.
- Detail data uses `/PWW/AgencyPickup/{Id}/GetDetailIndexData/`; it can be
  constructed directly from the pickup ID without loading each Detail page.
- History and detail responses use `TotalRecords`, `PageNumber`, `PageSize`, and
  `Data`, with the same jqxGrid pagination/filter parameter family used by
  Order History.
- The inspected completed Amazon pickup `461910` contained six category rows
  totaling 330 pounds. Their product numbers and weights exactly matched the
  existing order export's `809852AGPCKUP` rows, but Primarius exposed no stable
  field connecting the two different references. The extension therefore
  keeps the detailed pickup export separate instead of attempting a
  probabilistic join.
- All data sources are authenticated same-origin GET requests. No anti-forgery
  token or new Chrome permission is required.

## Primarius integration verified July 14, 2026

The authenticated, read-only inspection found this server-backed contract:

- Order History grid DOM ID: `grdOrderIndex`.
- Visible columns: View, Order Ref, Status, Released, Picked, Confirmed, Delivery/Pickup, Delivery/Pickup Location, Order Warehouse, and Pickup Warehouse. Entry Origin and Shipping Method are also defined columns.
- Stable history fields include `Id`, `ReferenceCode`, `SystemOrderStatusName`, `ReleasedDate`, `PickedCompleteDate`, `ConfirmedDate`, and `PickupDeliveryDate`. The View link is constructed as `/PWW/Order/{Id}/Detail/`.
- Primarius's completed-order value is `Confirmed`. The Complete grid source is `/PWW/Order/GetIndexData_CompletedOrders`; Active uses `/PWW/Order/GetIndexData_OpenOrders`.
- The grid supports server-side range filters on Released, Picked, Confirmed, and Delivery/Pickup, plus a Status text filter. The extension uses inclusive `PickupDeliveryDate` filters because that is the Date written to the CSV.
- Requests use jqxGrid GET parameters: `pagenum`, `pagesize`, `recordstartindex`, `recordendindex`, `filterscount`, `filterdatafieldN`, `filtervalueN`, `filterconditionN`, `filteroperatorN`, `groupscount`, `sortdatafield`, and `sortorder`.
- Responses are JSON objects with `Data` rows and `TotalRecords`. The live Complete view reported `1-10 of 2154` during inspection.
- A distinct `ConfirmedDate` exists and is the closest completion timestamp. It can differ from `PickupDeliveryDate`; it is available in the history response but does not define batch membership.
- Order details use `grdOrderDetailsIndex` and `/PWW/Order/{Id}/GetDetailIndexData/`. This pattern was verified on completed orders `558851` and `558763`, whose detail pages used the matching `/PWW/Order/{Id}/Detail/` pattern.
- Both history and detail data are same-origin authenticated GET requests. No anti-forgery token or per-page request value was present or required; the extension uses the existing signed-in browser session and never reads cookies or credentials.

For support, use the public [GitHub issue tracker](https://github.com/MattGeiger/ofb-order-csv-exporter/issues). Do not post order data or login information in a public issue.

## Reliability scope

Version 1.0.0 was validated against a private historical corpus covering 39 orders and 1,894 rows from October 2025 through July 2026. The final seven-order, 342-row holdout was not used to develop the parsing rules and passed without an unsupported live format.

This release is intentionally narrow: it supports the observed Oregon Food Bank Primarius Order History and order-detail layouts. If Primarius changes its fields or endpoints, the exporter fails with an on-page message instead of silently creating a partial file.

## Test

Install Node.js 20 or newer, then run:

```sh
npm test
```

The private reconciliation data is deliberately excluded from this repository. Public tests use synthetic order rows.

## Build a release

Run `npm run build:release` to create a versioned Chrome Web Store ZIP in
`dist/`. The package includes only runtime assets and project documentation.

## License

This project is free software licensed under the [GNU Affero General Public License, version 3](LICENSE) (`AGPL-3.0-only`).
