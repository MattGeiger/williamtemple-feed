(function attachOFBFreshAllianceCore(root, factory) {
  const exportCore = root.OFBExportCore || (
    typeof module === "object" && module.exports ? require("./export-core.js") : null
  );
  const api = factory(exportCore);
  root.OFBFreshAllianceCore = api;
  if (typeof module === "object" && module.exports) {
    module.exports = api;
  }
})(typeof globalThis !== "undefined" ? globalThis : this, function createOFBFreshAllianceCore(exportCore) {
  "use strict";

  if (!exportCore) throw new Error("OFBExportCore is required.");

  const HISTORY_ENDPOINT = "/PWW/AgencyPickup/GetIndexDataAgencyPickup_Completed";
  const HEADERS = [
    "Date",
    "Period",
    "Pickup Time",
    "Pickup ID",
    "Pickup Reference",
    "Pickup Line ID",
    "Donor Code",
    "Donor Name",
    "Product #",
    "Product Description",
    "Category",
    "Fresh Alliance Category",
    "Qty",
    "Weight",
    "Received Qty",
    "Received Weight",
    "Temperature",
    "Submitted Date/Time",
    "Donor Value Per Pound",
  ];

  function normalizeText(value) {
    return String(value ?? "").replace(/\s+/g, " ").trim();
  }

  function pad(value) {
    return String(value).padStart(2, "0");
  }

  function parseDateTime(value, label = "Primarius date/time") {
    if (value instanceof Date && Number.isFinite(value.getTime())) {
      return dateTimeParts(value);
    }

    const text = String(value ?? "").trim();
    const aspNet = text.match(/\/Date\((-?\d+)(?:[+-]\d{4})?\)\//i);
    if (aspNet) {
      const date = new Date(Number(aspNet[1]));
      if (!Number.isFinite(date.getTime())) throw new Error(`${label} is invalid.`);
      return dateTimeParts(date);
    }

    const mdy = text.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:\s+(\d{1,2}):(\d{2})(?::\d{2})?\s*(AM|PM)?)?/i);
    if (mdy) {
      let hour = Number(mdy[4] ?? 0);
      const minute = Number(mdy[5] ?? 0);
      const meridiem = String(mdy[6] ?? "").toUpperCase();
      if (meridiem === "PM" && hour < 12) hour += 12;
      if (meridiem === "AM" && hour === 12) hour = 0;
      return validateDateTimeParts({
        year: Number(mdy[3]),
        month: Number(mdy[1]),
        day: Number(mdy[2]),
        hour,
        minute,
      }, label);
    }

    const iso = text.match(/^(\d{4})-(\d{1,2})-(\d{1,2})(?:T|\s)?(\d{1,2})?:?(\d{2})?/);
    if (iso) {
      return validateDateTimeParts({
        year: Number(iso[1]),
        month: Number(iso[2]),
        day: Number(iso[3]),
        hour: Number(iso[4] ?? 0),
        minute: Number(iso[5] ?? 0),
      }, label);
    }
    throw new Error(`${label} is missing or uses an unsupported format.`);
  }

  function dateTimeParts(date) {
    return {
      year: date.getFullYear(),
      month: date.getMonth() + 1,
      day: date.getDate(),
      hour: date.getHours(),
      minute: date.getMinutes(),
    };
  }

  function validateDateTimeParts(parts, label) {
    const date = new Date(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute);
    if (
      date.getFullYear() !== parts.year ||
      date.getMonth() + 1 !== parts.month ||
      date.getDate() !== parts.day ||
      date.getHours() !== parts.hour ||
      date.getMinutes() !== parts.minute
    ) throw new Error(`${label} is invalid.`);
    return parts;
  }

  function dateKey(parts) {
    return `${parts.year}-${pad(parts.month)}-${pad(parts.day)}`;
  }

  function formatPickupDate(parts) {
    return `${parts.month}/${parts.day}/${String(parts.year).slice(-2)}`;
  }

  function formatTime(parts) {
    const meridiem = parts.hour >= 12 ? "PM" : "AM";
    const hour = parts.hour % 12 || 12;
    return `${hour}:${pad(parts.minute)} ${meridiem}`;
  }

  function formatDateTime(parts) {
    return `${parts.month}/${parts.day}/${parts.year} ${formatTime(parts)}`;
  }

  function buildPickupHistoryRequest(startDate, endDate, pageNumber = 0, pageSize = 50) {
    const start = exportCore.parseIsoDate(startDate, "Start date");
    const end = exportCore.parseIsoDate(endDate, "End date");
    if (dateKey(start) > dateKey(end)) throw new Error("Start date must be on or before End date.");
    if (!Number.isInteger(pageNumber) || pageNumber < 0) throw new Error("Page number is invalid.");
    if (!Number.isInteger(pageSize) || pageSize < 1 || pageSize > 50) throw new Error("Page size is invalid.");

    return {
      endpoint: HISTORY_ENDPOINT,
      data: {
        pagenum: pageNumber,
        pagesize: pageSize,
        recordstartindex: pageNumber * pageSize,
        recordendindex: (pageNumber + 1) * pageSize,
        filterscount: 2,
        groupscount: 0,
        filterdatafield0: "ExpectedDate",
        filtervalue0: `${start.month}/${start.day}/${start.year} 12:00:00 AM`,
        filtercondition0: "GREATER_THAN_OR_EQUAL",
        filteroperator0: 0,
        filterdatafield1: "ExpectedDate",
        filtervalue1: `${end.month}/${end.day}/${end.year} 11:59:59 PM`,
        filtercondition1: "LESS_THAN_OR_EQUAL",
        filteroperator1: 0,
        sortdatafield: "ExpectedDate",
        sortorder: "asc",
      },
    };
  }

  function donorParts(row) {
    const formatted = normalizeText(row?.ContributorId_FormattedValue);
    const formattedMatch = formatted.match(/^\(([^)]+)\)\s*-?\s*(.*)$/);
    return {
      code: normalizeText(row?.["ContributorId::Contributor.ReferenceCode"]) || normalizeText(formattedMatch?.[1]),
      name: normalizeText(row?.["ContributorId::Contributor.Name"]) || normalizeText(formattedMatch?.[2]),
    };
  }

  function systemReceivedValue(value, label) {
    if (value === true || String(value).toLowerCase() === "true") return true;
    if (value === false || String(value).toLowerCase() === "false") return false;
    throw new Error(`${label} is missing its System Received status.`);
  }

  function normalizePickups(rawRows, startDate, endDate, confirmed) {
    const statusLabel = confirmed ? "completed" : "pending";
    if (!Array.isArray(rawRows)) throw new Error(`The ${statusLabel}-pickup response did not contain rows.`);
    if (typeof confirmed !== "boolean") throw new Error("Pickup confirmation status is unavailable.");
    const startKey = dateKey(exportCore.parseIsoDate(startDate, "Start date"));
    const endKey = dateKey(exportCore.parseIsoDate(endDate, "End date"));
    if (startKey > endKey) throw new Error("Start date must be on or before End date.");

    const seen = new Set();
    const pickups = [];
    let duplicatesRemoved = 0;
    for (const row of rawRows) {
      const rowConfirmed = systemReceivedValue(row?.SystemReceived, `Pickup ${row?.ReferenceCode ?? row?.Id ?? "unknown"}`);
      if (rowConfirmed !== confirmed) {
        throw new Error(
          `The ${statusLabel}-pickup endpoint returned a pickup with the wrong System Received status.`,
        );
      }
      const id = Number(row?.Id);
      if (!Number.isInteger(id) || id <= 0) throw new Error(`A ${statusLabel} pickup is missing its stable internal ID.`);
      if (seen.has(id)) {
        duplicatesRemoved += 1;
        continue;
      }
      seen.add(id);

      const reference = normalizeText(row?.ReferenceCode);
      if (!reference) throw new Error(`${confirmed ? "Completed" : "Pending"} pickup ${id} is missing its reference.`);
      const pickupParts = parseDateTime(row?.ExpectedDate, `Pickup date for ${reference}`);
      const pickupDateKey = dateKey(pickupParts);
      if (pickupDateKey < startKey || pickupDateKey > endKey) continue;
      const donor = donorParts(row);
      if (!donor.code || !donor.name) throw new Error(`Completed pickup ${reference} is missing its donor code or name.`);
      const submittedParts = parseDateTime(row?.CreatedOn, `Submitted date for ${reference}`);

      pickups.push({
        id,
        reference,
        confirmed,
        donorId: Number(row?.ContributorId) || null,
        donorCode: donor.code,
        donorName: donor.name,
        pickupDate: formatPickupDate(pickupParts),
        pickupTime: formatTime(pickupParts),
        pickupDateKey,
        pickupMinuteOfDay: pickupParts.hour * 60 + pickupParts.minute,
        submittedDateTime: formatDateTime(submittedParts),
        detailDataUrl: `/PWW/AgencyPickup/${id}/GetDetailIndexData/`,
      });
    }

    pickups.sort(comparePickups);
    return { pickups, duplicatesRemoved };
  }

  function normalizeCompletedPickups(rawRows, startDate, endDate) {
    return normalizePickups(rawRows, startDate, endDate, true);
  }

  function normalizePendingPickups(rawRows, startDate, endDate) {
    return normalizePickups(rawRows, startDate, endDate, false);
  }

  function comparePickups(a, b) {
    return (
      a.pickupDateKey.localeCompare(b.pickupDateKey) ||
      a.pickupMinuteOfDay - b.pickupMinuteOfDay ||
      a.donorCode.localeCompare(b.donorCode, "en", { numeric: true, sensitivity: "base" }) ||
      a.id - b.id
    );
  }

  function finiteNumber(value, label, { optional = false } = {}) {
    if (optional && (value === null || value === undefined || value === "")) return null;
    const parsed = Number(String(value ?? "").replace(/[$,\s]/g, ""));
    if (!Number.isFinite(parsed)) throw new Error(`${label} is not a valid number.`);
    return parsed;
  }

  function formatNumber(value) {
    return value === null ? "" : Number(value).toFixed(2);
  }

  function productParts(row) {
    const productNumber = normalizeText(row?.["ProductId::Product.ReferenceCode"]);
    const description = normalizeText(row?.["ProductId::Product.Name"]);
    if (productNumber && description) return { productNumber, description };

    const formatted = normalizeText(row?.ProductId_FormattedValue);
    const match = formatted.match(/^\((?:C-)?(\d{4,6})(?:[xz]|-z|\.[01])?\)\s*-?\s*(.*)$/i);
    if (!match || !normalizeText(match[2])) {
      throw new Error(`Could not read a supported Fresh Alliance product from: ${formatted || "(blank)"}`);
    }
    return { productNumber: match[1], description: normalizeText(match[2]) };
  }

  function buildPickupExport(pickup, rawRows) {
    if (!pickup || !Number.isInteger(Number(pickup.id))) throw new Error("Pickup metadata is unavailable.");
    if (!Array.isArray(rawRows)) throw new Error(`Pickup ${pickup.reference} did not contain detail rows.`);

    const seen = new Set();
    const records = [];
    let requestedWeight = 0;
    let receivedWeight = 0;
    let receivedWeightMissing = 0;
    let discrepancyLines = 0;

    for (const row of rawRows) {
      const lineId = Number(row?.Id);
      if (!Number.isInteger(lineId) || lineId <= 0) throw new Error(`Pickup ${pickup.reference} contains a line without a stable ID.`);
      if (seen.has(lineId)) throw new Error(`Pickup ${pickup.reference} returned duplicate detail line ${lineId}.`);
      seen.add(lineId);
      if (Number(row?.ReceiptId) !== Number(pickup.id)) {
        throw new Error(`Pickup line ${lineId} belongs to receipt ${row?.ReceiptId ?? "unknown"}, not pickup ${pickup.id}.`);
      }

      const product = productParts(row);
      const requestedQty = finiteNumber(row?.RequestedQuantity, `Requested quantity for line ${lineId}`);
      const requestedLineWeight = finiteNumber(row?.RequestedWeight, `Requested weight for line ${lineId}`);
      const receivedQty = finiteNumber(row?.ReceivedQuantity, `Received quantity for line ${lineId}`, { optional: true });
      const receivedLineWeight = finiteNumber(row?.ReceivedWeight, `Received weight for line ${lineId}`, { optional: true });
      const temperature = finiteNumber(row?.Temperature, `Temperature for line ${lineId}`, { optional: true });
      const donorValue = finiteNumber(row?.DonorValuePerPound, `Donor value per pound for line ${lineId}`, { optional: true });

      requestedWeight += requestedLineWeight;
      if (receivedLineWeight === null) receivedWeightMissing += 1;
      else receivedWeight += receivedLineWeight;
      if (
        receivedQty === null || receivedLineWeight === null ||
        requestedQty !== receivedQty || requestedLineWeight !== receivedLineWeight
      ) discrepancyLines += 1;

      records.push({
        lineId,
        productNumber: product.productNumber,
        values: [
          pickup.pickupDate,
          exportCore.parsePickupDate(`${pickup.pickupDate.slice(0, -2)}20${pickup.pickupDate.slice(-2)}`).period,
          pickup.pickupTime,
          String(pickup.id),
          pickup.reference,
          String(lineId),
          pickup.donorCode,
          pickup.donorName,
          product.productNumber,
          product.description,
          exportCore.categoryFromProductNumber(product.productNumber),
          normalizeText(row?.FaProductCategoryId_FormattedValue),
          formatNumber(requestedQty),
          formatNumber(requestedLineWeight),
          formatNumber(receivedQty),
          formatNumber(receivedLineWeight),
          formatNumber(temperature),
          pickup.submittedDateTime,
          formatNumber(donorValue),
        ],
      });
    }

    records.sort((a, b) => (
      a.productNumber.localeCompare(b.productNumber, "en", { numeric: true, sensitivity: "base" }) ||
      a.lineId - b.lineId
    ));
    return {
      rows: records.map((record) => record.values),
      requestedWeight,
      receivedWeight,
      receivedWeightMissing,
      discrepancyLines,
    };
  }

  function pickupRowSortKey(row) {
    const date = exportCore.parsePickupDate(String(row[0]).replace(/\/(\d{2})$/, "/20$1")).isoDate;
    const time = String(row[2]).match(/^(\d{1,2}):(\d{2})\s+(AM|PM)$/i);
    let minute = 0;
    if (time) {
      let hour = Number(time[1]) % 12;
      if (time[3].toUpperCase() === "PM") hour += 12;
      minute = hour * 60 + Number(time[2]);
    }
    return { date, minute };
  }

  function combinePickupExports(exports) {
    if (!Array.isArray(exports)) throw new Error("Fresh Alliance pickup exports are unavailable.");
    const rows = exports.flatMap((entry) => {
      if (!Array.isArray(entry?.rows)) throw new Error("A Fresh Alliance pickup export did not contain rows.");
      return entry.rows;
    });
    return rows.slice().sort((a, b) => {
      const aKey = pickupRowSortKey(a);
      const bKey = pickupRowSortKey(b);
      return (
        aKey.date.localeCompare(bKey.date) ||
        aKey.minute - bKey.minute ||
        String(a[6]).localeCompare(String(b[6]), "en", { numeric: true, sensitivity: "base" }) ||
        Number(a[3]) - Number(b[3]) ||
        String(a[8]).localeCompare(String(b[8]), "en", { numeric: true, sensitivity: "base" }) ||
        Number(a[5]) - Number(b[5])
      );
    });
  }

  function buildFilename(startDate, endDate) {
    exportCore.parseIsoDate(startDate, "Start date");
    exportCore.parseIsoDate(endDate, "End date");
    return `OFB_Fresh_Alliance_Pickups_${startDate}_to_${endDate}.csv`;
  }

  function toCsv(rows) {
    if (!Array.isArray(rows)) throw new Error("Fresh Alliance CSV rows are unavailable.");
    return [HEADERS, ...rows].map((row) => row.map(exportCore.escapeCsv).join(",")).join("\r\n");
  }

  return {
    HEADERS,
    HISTORY_ENDPOINT,
    buildFilename,
    buildPickupExport,
    buildPickupHistoryRequest,
    combinePickupExports,
    normalizeCompletedPickups,
    normalizePendingPickups,
    normalizePickups,
    parseDateTime,
    toCsv,
  };
});
