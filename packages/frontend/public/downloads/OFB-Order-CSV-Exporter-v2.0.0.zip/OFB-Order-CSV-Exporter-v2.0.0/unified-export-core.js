(function attachOFBUnifiedExportCore(root, factory) {
  const exportCore = root.OFBExportCore || (
    typeof module === "object" && module.exports ? require("./export-core.js") : null
  );
  const freshCore = root.OFBFreshAllianceCore || (
    typeof module === "object" && module.exports ? require("./fresh-alliance-core.js") : null
  );
  const api = factory(exportCore, freshCore);
  root.OFBUnifiedExportCore = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function createOFBUnifiedExportCore(exportCore, freshCore) {
  "use strict";

  if (!exportCore || !freshCore) throw new Error("The order and Fresh Alliance export helpers are required.");

  const SCHEMA_VERSION = "2.0";
  const RECORD_TYPES = Object.freeze({
    WAREHOUSE: "warehouse_order",
    PICKUP: "agency_pickup",
  });
  const HEADERS = [
    "Schema Version",
    "Record Type",
    "Confirmed",
    "Date",
    "Period",
    "Source Reference",
    "Product #",
    "Product Description",
    "Category",
    "Qty",
    "Weight",
    "Unit Price",
    "Price Total",
    "Service Fee",
    "Grants Applied",
    "Pickup Time",
    "Pickup ID",
    "Pickup Line ID",
    "Donor Code",
    "Donor Name",
    "Fresh Alliance Category",
    "Received Qty",
    "Received Weight",
    "Temperature",
    "Submitted Date/Time",
    "Donor Value Per Pound",
  ];

  function normalizeWarehouseOrders(rawRows, startDate, endDate) {
    const normalized = exportCore.normalizeCompletedOrders(rawRows, startDate, endDate);
    const orders = [];
    const excludedAgencyPickupOrders = [];
    const idByReference = new Map();
    for (const order of normalized.orders) {
      const existingId = idByReference.get(order.reference);
      if (existingId && existingId !== order.id) {
        throw new Error(`Warehouse order reference ${order.reference} was returned with more than one stable ID.`);
      }
      idByReference.set(order.reference, order.id);
      if (/AGPCKUP$/i.test(order.reference)) excludedAgencyPickupOrders.push(order);
      else orders.push(order);
    }
    return {
      orders,
      excludedAgencyPickupOrders,
      duplicatesRemoved: normalized.duplicatesRemoved,
    };
  }

  function comparePickups(a, b) {
    return (
      a.pickupDateKey.localeCompare(b.pickupDateKey) ||
      a.pickupMinuteOfDay - b.pickupMinuteOfDay ||
      a.donorCode.localeCompare(b.donorCode, "en", { numeric: true, sensitivity: "base" }) ||
      a.id - b.id
    );
  }

  function mergePickupSnapshots(pendingPickups, completedPickups) {
    if (!Array.isArray(pendingPickups) || !Array.isArray(completedPickups)) {
      throw new Error("Pending and completed pickup snapshots are required.");
    }

    const byReference = new Map();
    const referenceById = new Map();
    let transitionDuplicatesRemoved = 0;

    function record(pickup, expectedConfirmed) {
      if (!pickup || pickup.confirmed !== expectedConfirmed) {
        throw new Error(`A pickup has an invalid ${expectedConfirmed ? "completed" : "pending"} status.`);
      }
      const id = Number(pickup.id);
      const reference = String(pickup.reference ?? "").trim();
      if (!Number.isInteger(id) || id <= 0 || !reference) {
        throw new Error("A pickup is missing its stable ID or reference.");
      }

      const idReference = referenceById.get(id);
      if (idReference && idReference !== reference) {
        throw new Error(`Pickup ID ${id} was returned with more than one reference.`);
      }
      referenceById.set(id, reference);

      const existing = byReference.get(reference);
      if (!existing) {
        byReference.set(reference, pickup);
        return;
      }
      if (Number(existing.id) !== id) {
        throw new Error(`Pickup reference ${reference} was returned with more than one stable ID.`);
      }
      if (existing.confirmed === pickup.confirmed) {
        throw new Error(`Pickup reference ${reference} was returned more than once in the same status.`);
      }
      if (pickup.confirmed) {
        byReference.set(reference, pickup);
        transitionDuplicatesRemoved += 1;
      }
    }

    // Pending must be sampled first. A Pending -> Completed transition between
    // snapshots then appears twice and is safely resolved in favor of Completed.
    // Reversing this order could omit the transitioning pickup from both snapshots.
    pendingPickups.forEach((pickup) => record(pickup, false));
    completedPickups.forEach((pickup) => record(pickup, true));

    return {
      pickups: Array.from(byReference.values()).sort(comparePickups),
      transitionDuplicatesRemoved,
    };
  }

  function buildWarehouseExport(order, sourceRows) {
    if (/AGPCKUP$/i.test(String(order?.reference ?? ""))) {
      throw new Error("Fresh Alliance AGPCKUP orders cannot be emitted as warehouse rows.");
    }
    const legacyRows = exportCore.buildExportRows({
      orderReference: order.reference,
      pickupDeliveryDate: order.pickupDeliveryDate,
    }, sourceRows);
    return {
      rows: legacyRows.map((row) => [
        SCHEMA_VERSION,
        RECORD_TYPES.WAREHOUSE,
        "Yes",
        row[0],
        row[1],
        row[2],
        row[3],
        row[4],
        row[5],
        row[6],
        row[7],
        row[8],
        row[9],
        row[10],
        row[11],
        "", "", "", "", "", "", "", "", "", "", "",
      ]),
    };
  }

  function buildPickupExport(pickup, rawRows) {
    const legacy = freshCore.buildPickupExport(pickup, rawRows);
    return {
      ...legacy,
      rows: legacy.rows.map((row) => [
        SCHEMA_VERSION,
        RECORD_TYPES.PICKUP,
        pickup.confirmed ? "Yes" : "No",
        row[0],
        row[1],
        row[4],
        row[8],
        row[9],
        row[10],
        row[12],
        row[13],
        "", "", "", "",
        row[2],
        row[3],
        row[5],
        row[6],
        row[7],
        row[11],
        row[14],
        row[15],
        row[16],
        row[17],
        row[18],
      ]),
    };
  }

  function rowDateKey(row) {
    return exportCore.parsePickupDate(String(row[3]).replace(/\/(\d{2})$/, "/20$1")).isoDate;
  }

  function combineRows(exports) {
    if (!Array.isArray(exports)) throw new Error("Unified exports are unavailable.");
    const rows = exports.flatMap((entry) => {
      if (!Array.isArray(entry?.rows)) throw new Error("A unified export did not contain rows.");
      return entry.rows;
    });
    return rows.slice().sort((a, b) => (
      rowDateKey(a).localeCompare(rowDateKey(b)) ||
      String(a[1]).localeCompare(String(b[1])) ||
      String(a[5]).localeCompare(String(b[5]), "en", { numeric: true, sensitivity: "base" }) ||
      String(a[6]).localeCompare(String(b[6]), "en", { numeric: true, sensitivity: "base" }) ||
      String(a[17]).localeCompare(String(b[17]), "en", { numeric: true, sensitivity: "base" })
    ));
  }

  function buildFilename(startDate, endDate) {
    exportCore.parseIsoDate(startDate, "Start date");
    exportCore.parseIsoDate(endDate, "End date");
    return `OFB_Export_${startDate}_to_${endDate}.csv`;
  }

  function toCsv(rows) {
    if (!Array.isArray(rows)) throw new Error("Unified CSV rows are unavailable.");
    for (const row of rows) {
      if (!Array.isArray(row) || row.length !== HEADERS.length) {
        throw new Error("A unified CSV row does not match the v2.0 schema.");
      }
    }
    return [HEADERS, ...rows].map((row) => row.map(exportCore.escapeCsv).join(",")).join("\r\n");
  }

  return {
    HEADERS,
    RECORD_TYPES,
    SCHEMA_VERSION,
    buildFilename,
    buildPickupExport,
    buildWarehouseExport,
    combineRows,
    mergePickupSnapshots,
    normalizeWarehouseOrders,
    toCsv,
  };
});
